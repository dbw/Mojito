# License Creator

A portable Qt application for creating license keys using the LimeLM WebAPI.

## Features

- Generate product keys using LimeLM API
- Input product name, customer email, and number of keys
- View and manage previously generated licenses
- Portable ZIP package via CPack - no Qt or Visual C++ runtime installation required

## Prerequisites

- Qt 6.11.2 for MSVC 2022 (64-bit), installed at `C:\Qt\6.11.2\msvc2022_64`
- Visual Studio 2022 (C++ desktop workload)
- CMake (in `PATH`, or bundled with Visual Studio)

## Building

Run `build.bat` from the project directory:

```bat
build.bat
```

The script configures CMake (Visual Studio 17 2022, x64) and builds the
`Release` configuration. After the build, `windeployqt` automatically copies the
required Qt6 DLLs and plugins next to the executable, so
`build\Release\license_creator.exe` can be started directly.

Manual equivalent:

```bat
mkdir build && cd build
cmake .. -G "Visual Studio 17 2022" -A x64
cmake --build . --config Release --parallel
```

## Creating the portable package

Run `deploy.bat`:

```bat
deploy.bat
```

It rebuilds `Release`, runs CPack and writes:

- `build\package\license_creator_windows.zip` (+ `.sha256` checksum)
- a copy at `license_creator_windows.zip` in the project root

The ZIP is self-contained and portable:

```
license_creator_windows\
    license_creator.exe
    Qt6Core.dll, Qt6Gui.dll, Qt6Widgets.dll, Qt6Network.dll, Qt6Svg.dll
    msvcp140*.dll, vcruntime140*.dll, concrt140.dll   (MSVC runtime)
    qt.conf
    plugins\
        platforms\qwindows.dll
        imageformats\, iconengines\, styles\, tls\, networkinformation\
    README.md, LICENSE.txt
```

Extract it anywhere and start `license_creator.exe` - Qt6 and the MSVC runtime
are bundled, so nothing has to be installed (Windows 10 or newer).

Manual equivalent (from the `build` directory):

```bat
cpack -G ZIP -C Release
```

## Usage

1. Enter your LimeLM API key (configure in the application settings)
2. Enter the product name
3. Enter the customer email address
4. Specify the number of keys to generate
5. Click "Generate Keys"

The generated keys will be displayed and stored in the application's history.
